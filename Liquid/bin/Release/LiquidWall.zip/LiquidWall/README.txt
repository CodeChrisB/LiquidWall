==================================================
=  / /(_) __ _ _   _(_) __| |= __    __      _ _ =
= / / | |/ _` | | | | |/ _` |=/ / /\ \ \__ _| | |=
=/ /__| | (_| | |_| | | (_| |=\ \/  \/ / _` | | |=
=\____|_|\__, |\__,_|_|\__,_|= \  /\  | (_| | | |=
=           |_|              =  \/  \/ \__,_|_|_|=
==============================================================
=Made by CodeChrisB --> https://www.instagram.com/codechrisb/=
==============================================================
= This is a simple undetected hack.=
= -->Radarhack  ====================
= -->Wallhack   =
= -->Anti-Flash	=
=================


USE AT YOUR OWN RISK, IM NOT RESPONSIBLE IF YOU GET BANNED.
The cheat cannot be detected from the last reverse engineered 
VAC Version im aware of --> https://github.com/danielkrupinski/VAC

How to not get banned :
--> Do not aim at enemies behind walls
--> Do not Wallbang everyone
--> Play as like you dont have Wall/Radarhack
--> If they say you hack dont respond
--> Rember your matches maybe get Overwatched.